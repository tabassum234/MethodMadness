
public class Runner
{
	public static void main(isPalindrome)
	{
		
	}


}
